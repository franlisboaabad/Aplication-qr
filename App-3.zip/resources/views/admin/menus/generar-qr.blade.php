@extends('adminlte::page')

@section('title', 'Generar codigo qr')

@section('content_header')
    <h1>Generación de codigo QR</h1>
@stop

@section('content')
    {{-- <p>Welcome to this beautiful admin panel.</p> --}}
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="form-group">
                    <label for="">Ingresar URL</label>
                    <input type="text" id="qr" class="form-control" required>
                </div>

                <div class="form-group">
                    <button type="button" class="btn btn-warning" id="btn_generar">GENERAR CODIGO QR</button>
                </div>
            </form>


            <div id="codigoQRContainer"></div>
        </div>
    </div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script>
        $(document).ready(function() {

            $('#btn_generar').click(function(e) {
                e.preventDefault();
                var url = $("#qr").val();

                if (url.length > 0) {

                    $.ajax({
                        type: "POST", // Método de envío (puedes usar "GET" o "POST" según tus necesidades)
                        url: "/generar-qr-carta-digital", // URL del controlador que recibirá la solicitud AJAX
                        data: {
                            _token: "{{ csrf_token() }}", // Agregar el token CSRF para protección contra CSRF
                            url: url // Enviar el valor del input al controlador con la clave "url"
                        },
                        success: function(response) {
                            // Manejar la respuesta del controlador
                            $("#codigoQRContainer").html(response);
                        },
                        error: function(xhr, status, error) {
                            // Manejar errores si los hay
                            console.error(error);
                        }
                    });

                } else { alert('Ingresar texto url para generar el codigo QR') }


            });
        });
    </script>
@stop
