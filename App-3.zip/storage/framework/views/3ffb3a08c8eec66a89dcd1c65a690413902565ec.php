

<?php $__env->startSection('title', 'Lista de usuarios'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Lista de Usuarios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-body">
            <a href="<?php echo e(route('users.create')); ?>" class="btn  btn-success"><i class="fa fa-user"></i> Nuevo Usuario</a>
            <hr>

            <?php echo $__env->make('partials.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          

            <table class="table" >
                <thead>
                    <th>#</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Opciones</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($usuario->id); ?></td>
                            <td><?php echo e($usuario->name); ?></td>
                            <td><?php echo e($usuario->email); ?></td>
                            <td>
                                <form action="<?php echo e(route('users.destroy', $usuario)); ?>" method="POST">

                                    <a href="<?php echo e(route('users.edit', $usuario)); ?>" class="btn btn-info btn-xs">Editar</a>

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-xs"
                                        onclick="return confirm('¿Esta seguro de eliminar el registro?')">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\App_qr\resources\views/admin/usuarios/index.blade.php ENDPATH**/ ?>