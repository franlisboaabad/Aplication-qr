<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Carta digital qr - <?php echo e($titulo); ?> </title>
    <style>
        body,
        html {
            height: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        div {
            position: relative;
        }

        img {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -100%);
        }
    </style>

<body>
    <div>
        <img src="<?php echo e($qrCode); ?>" alt="<?php echo e($titulo); ?>">
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\App_qr\resources\views/carta.blade.php ENDPATH**/ ?>