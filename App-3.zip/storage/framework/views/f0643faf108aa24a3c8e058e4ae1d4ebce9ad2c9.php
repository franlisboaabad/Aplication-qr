

<?php $__env->startSection('title', 'Editar carta digital'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Editar carta digital</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card">


                <?php echo $__env->make('partials.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <div class="card-body">
                    <form action="<?php echo e(route('cartas.update', $carta)); ?>" method="POST" enctype="multipart/form-data">

                        <div class="form-group">
                            <label for="">Nombre de compañia</label>
                            <input type="text" name="nombre_empresa" value="<?php echo e(old('nombre_empresa', $carta->nombre_empresa)); ?>"
                                class="form-control" required>
                        </div>


                        <div class="form-group">
                            <label for="">Documento carta PDF</label>
                            <input type="file" name="carta_path" class="form-control"> <br>
                            <span><?php echo e($carta->carta_path); ?></span>
                        </div>


                        <div class="form-group">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button type="submit" class="btn btn-primary btn-xs">ACTUALIZAR CARTA</button>
                            <a href="<?php echo e(route('cartas.index')); ?>" class="btn btn-danger btn-xs">Lista de cartas</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <iframe src="<?php echo e($carta->getCarta); ?>" frameborder="0" height="600" width="500"></iframe>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        console.log('Hi!');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\App_qr\resources\views/admin/cartas/edit.blade.php ENDPATH**/ ?>