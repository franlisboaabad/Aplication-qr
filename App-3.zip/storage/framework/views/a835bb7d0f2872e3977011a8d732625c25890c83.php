

<?php $__env->startSection('title', 'Cartas digitales'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Lista de cartas digitales</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-body">
            <a href="<?php echo e(route('cartas.create')); ?>" class="btn btn-success"> <i class="fa fa-file-pdf"></i> Nueva carta</a>


            <?php echo $__env->make('partials.validaciones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            
            <table class="table mb-3">
                <thead>
                    <th>Id</th>
                    <th>Empresa</th>
                    <th>Carta Url</th>
                    <th>Estado</th>
                    <th>Configuraciones</th>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $cartas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($carta->id); ?></td>
                            <td><?php echo e($carta->nombre_empresa); ?></td>
                            <td>
                                <a href="<?php echo e($carta->getCarta); ?>" target="_Blank">Ver carta digital</a>
                            </td>
                            <td>
                                <span class="badge <?php echo e($carta->estado ? 'badge-activo' : 'badge-inactivo'); ?>">
                                    <?php echo e($carta->estado ? 'Activo' : 'Inactivo'); ?>

                                </span>
                            </td>
                            <td>
                                <form action="<?php echo e(route('cartas.destroy', $carta)); ?>" method="POST">



                                    <a href="<?php echo e(route('cartas.generar-codigo-qr', $carta)); ?>" title="Descargar qr"
                                        class="btn btn-warning btn-xs" target="_Blank"> <i class="fa fa-file"></i></a>

                                        
                                    <a href="<?php echo e(route('cartas.edit', $carta)); ?>" class="btn btn-success btn-xs"
                                        title="Editar"> <i class="fa fa-edit"></i> </a>



                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-xs"
                                        onclick="return confirm('¿Esta seguro de eliminar el registro?')" title="Eliminar">
                                        <i class="fa fa-trash"></i> </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </tbody>



            </table>

            <?php echo e($cartas->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        /* Estilos para el badge cuando está activo */
        .badge-activo {
            background-color: #4CAF50;
            /* Cambia el color de fondo a tu preferencia */
            color: white;
            /* Cambia el color del texto a tu preferencia */
        }

        /* Estilos para el badge cuando está inactivo */
        .badge-inactivo {
            background-color: #f44336;
            /* Cambia el color de fondo a tu preferencia */
            color: white;
            /* Cambia el color del texto a tu preferencia */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        console.log('Hi!');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\App_qr\resources\views/admin/cartas/index.blade.php ENDPATH**/ ?>