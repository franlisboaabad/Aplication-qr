

<?php $__env->startSection('title', 'Generar codigo qr'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Generación de codigo QR</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="form-group">
                    <label for="">Ingresar URL</label>
                    <input type="text" id="qr" class="form-control" required>
                </div>

                <div class="form-group">
                    <button type="button" class="btn btn-warning" id="btn_generar">GENERAR CODIGO QR</button>
                </div>
            </form>


            <div id="codigoQRContainer"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {

            $('#btn_generar').click(function(e) {
                e.preventDefault();
                var url = $("#qr").val();

                if (url.length > 0) {

                    $.ajax({
                        type: "POST", // Método de envío (puedes usar "GET" o "POST" según tus necesidades)
                        url: "/generar-qr-carta-digital", // URL del controlador que recibirá la solicitud AJAX
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>", // Agregar el token CSRF para protección contra CSRF
                            url: url // Enviar el valor del input al controlador con la clave "url"
                        },
                        success: function(response) {
                            // Manejar la respuesta del controlador
                            $("#codigoQRContainer").html(response);
                        },
                        error: function(xhr, status, error) {
                            // Manejar errores si los hay
                            console.error(error);
                        }
                    });

                } else { alert('Ingresar texto url para generar el codigo QR') }


            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\App_qr\resources\views/admin/menus/generar-qr.blade.php ENDPATH**/ ?>